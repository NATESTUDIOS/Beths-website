package com.myjava.connectors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConnectorsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConnectorsApplication.class, args);
	}

}
